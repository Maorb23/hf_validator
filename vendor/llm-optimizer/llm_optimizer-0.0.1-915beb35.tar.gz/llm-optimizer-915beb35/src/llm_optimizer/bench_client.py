# Adapted from https://github.com/vllm-project/vllm/blob/6366efc67b0aedd2c1721c14385370e50b297fb3/benchmarks/backend_request_func.py
# Adapted from https://github.com/vllm-project/vllm/blob/6366efc67b0aedd2c1721c14385370e50b297fb3/benchmarks/benchmark_serving.py
# Adapted from https://github.com/sgl-project/sglang/blob/main/python/sglang/bench_serving.py

"""
Benchmark online serving with dynamic requests.

Usage:
python3 -m sglang.bench_serving --backend sglang --num-prompt 10

python3 -m sglang.bench_serving --backend sglang --dataset-name random --num-prompts 3000 --random-input 1024 --random-output 1024 --random-range-ratio 0.5
"""

from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import os
import platform
import pickle
import random
import resource
import sys
import time
import traceback
import typing as t
import warnings
from argparse import ArgumentParser
from collections.abc import AsyncGenerator
from dataclasses import dataclass, field
from functools import lru_cache
from json import JSONDecodeError
from pathlib import Path
from typing import Any, Optional, Union

import aiohttp
import numpy as np
import requests
from tqdm.asyncio import tqdm
try:
    from transformers import (
        AutoTokenizer,
        PreTrainedTokenizer,
        PreTrainedTokenizerBase,
        PreTrainedTokenizerFast,
    )
except ImportError:  # Keep metric/unit-test imports lightweight.
    AutoTokenizer = None
    PreTrainedTokenizer = t.Any
    PreTrainedTokenizerBase = t.Any
    PreTrainedTokenizerFast = t.Any

ASSISTANT_SUFFIX = "Assistant:"


# don't want to import sglang package here
def _get_bool_env_var(name: str, default: str = "false") -> bool:
    value = os.getenv(name, default)
    return value.lower() in ("true", "1")


def _create_bench_client_session():
    # When the pressure is big, the read buffer could be full before aio thread read
    # the content. We increase the read_bufsize from 64K to 10M.
    # Define constants for timeout and buffer size for clarity and maintainability
    BENCH_AIOHTTP_TIMEOUT_SECONDS = 6 * 60 * 60  # 6 hours
    BENCH_AIOHTTP_READ_BUFSIZE_BYTES = 10 * 1024**2  # 10 MB

    aiohttp_timeout = aiohttp.ClientTimeout(total=BENCH_AIOHTTP_TIMEOUT_SECONDS)
    return aiohttp.ClientSession(
        timeout=aiohttp_timeout, read_bufsize=BENCH_AIOHTTP_READ_BUFSIZE_BYTES
    )


@dataclass
class RequestFuncInput:
    prompt: str
    api_url: str
    prompt_len: int
    output_len: int
    model: str
    lora_name: str
    image_data: str
    extra_request_body: dict[str, Any]


@dataclass
class RequestFuncOutput:
    generated_text: str = ""
    success: bool = False
    latency: float = 0.0
    ttft: float = 0.0  # Time to first token
    itl: list[float] = field(default_factory=list)  # List of inter-token latencies
    prompt_len: int = 0
    error: str = ""
    error_category: str = ""
    output_len: int = 0
    usage: dict[str, Any] = field(default_factory=dict)
    output_len_is_estimate: bool = False

    @staticmethod
    def init_new(request_func_input: RequestFuncInput):
        output = RequestFuncOutput()
        output.prompt_len = request_func_input.prompt_len
        return output


def classify_error(error: str, status: Optional[int] = None) -> str:
    """Return a stable, small error vocabulary for benchmark accounting."""
    text = (error or "").lower()
    if status is not None:
        if status in (408, 429):
            return "request_rejected"
        if status >= 500:
            if "out of memory" in text or "oom" in text:
                return "oom"
            return "server_error"
        if status >= 400:
            return "request_rejected"
    if "timeout" in text or "timed out" in text:
        return "timeout"
    if "out of memory" in text or "oom" in text:
        return "oom"
    if "cancel" in text:
        return "cancelled"
    return "client_error"


def _mark_failure(output: RequestFuncOutput, error: str, status: Optional[int] = None):
    output.success = False
    output.error = error
    output.error_category = classify_error(error, status)


def _mark_success_or_empty_failure(output: RequestFuncOutput) -> None:
    if output.ttft <= 0.0:
        _mark_failure(output, "Successful response contained no streamed token.")
    else:
        output.success = True


async def _response_error(response: Any) -> str:
    """Include response text so backend OOM messages can be categorized."""
    error = response.reason or ""
    try:
        body = await response.text()
    except Exception:
        body = ""
    return f"{error}: {body}" if body else error


def request_errors(outputs, indices=None):
    """Bounded diagnostics without request/response bodies or tracebacks."""
    indices = range(len(outputs)) if indices is None else indices
    errors = []
    for index, output in zip(indices, outputs):
        if output.success:
            continue
        reason = output.error
        # Other backend handlers can contain arbitrary response bodies/tracebacks.
        if reason == "Successful response contained no streamed token.":
            pass
        elif output.error_category not in {
            "empty_response",
            "malformed_event",
            "interrupted_stream",
        }:
            category = output.error_category or classify_error(reason)
            reason = f"Request failed ({category}); inspect server logs"
        errors.append(
            {
                "request_index": index,
                "category": output.error_category or classify_error(output.error),
                "error": reason[:2000],
            }
        )
        if len(errors) == 20:
            break
    return errors


def remove_prefix(text: str, prefix: str) -> str:
    return text[len(prefix) :] if text.startswith(prefix) else text


def remove_suffix(text: str, suffix: str) -> str:
    return text[: -len(suffix)] if text.endswith(suffix) else text


def get_auth_headers() -> dict[str, str]:
    api_key = os.environ.get("OPENAI_API_KEY")
    if api_key:
        return {"Authorization": f"Bearer {api_key}"}
    else:
        return {}


# trt llm does not support ignore_eos
# https://github.com/triton-inference-server/tensorrtllm_backend/issues/505
async def async_request_trt_llm(
    request_func_input: RequestFuncInput,
    pbar: Optional[tqdm] = None,
    disable_ignore_eos: bool = False,
) -> RequestFuncOutput:
    api_url = request_func_input.api_url
    assert api_url.endswith("generate_stream")

    async with _create_bench_client_session() as session:
        payload = {
            "accumulate_tokens": True,
            "text_input": request_func_input.prompt,
            "temperature": 0.000001,
            "top_p": 1.0,
            "max_tokens": request_func_input.output_len,
            "stream": True,
            "min_length": request_func_input.output_len,
            "end_id": 1048576,
            **request_func_input.extra_request_body,
        }
        if disable_ignore_eos:
            del payload["min_length"]
            del payload["end_id"]
        output = RequestFuncOutput.init_new(request_func_input)

        ttft = 0.0
        st = time.perf_counter()
        most_recent_timestamp = st
        try:
            async with session.post(url=api_url, json=payload) as response:
                if response.status == 200:
                    async for chunk_bytes in response.content:
                        chunk_bytes = chunk_bytes.strip()
                        if not chunk_bytes:
                            continue

                        chunk = remove_prefix(chunk_bytes.decode("utf-8"), "data:")

                        data = json.loads(chunk)
                        output.generated_text += data["text_output"]
                        timestamp = time.perf_counter()
                        # First token
                        if ttft == 0.0:
                            ttft = timestamp - st
                            output.ttft = ttft

                        # Decoding phase
                        else:
                            output.itl.append(timestamp - most_recent_timestamp)

                        most_recent_timestamp = timestamp

                    output.latency = most_recent_timestamp - st
                    _mark_success_or_empty_failure(output)
                    output.output_len = request_func_input.output_len

                else:
                    _mark_failure(output, await _response_error(response), response.status)
        except Exception:
            exc_info = sys.exc_info()
            _mark_failure(output, "".join(traceback.format_exception(*exc_info)))

        if pbar:
            pbar.update(1)
        return output


# set ignore_eos True by default
async def async_request_openai_completions(
    request_func_input: RequestFuncInput,
    pbar: Optional[tqdm] = None,
    disable_stream: bool = False,
    disable_ignore_eos: bool = False,
) -> RequestFuncOutput:
    api_url = request_func_input.api_url
    assert api_url.endswith("completions"), (
        "OpenAI Completions API URL must end with 'completions'."
    )

    prompt = request_func_input.prompt

    async with _create_bench_client_session() as session:
        payload = {
            "model": request_func_input.model,
            "prompt": prompt,
            "temperature": 0.0,
            "best_of": 1,
            "max_tokens": request_func_input.output_len,
            "stream": not disable_stream,
            "ignore_eos": not disable_ignore_eos,
            **request_func_input.extra_request_body,
        }
        headers = get_auth_headers()

        output = RequestFuncOutput.init_new(request_func_input)

        st = time.perf_counter()
        most_recent_timestamp = st
        terminated = False
        finished = False

        class CompletionEventError(ValueError):
            """Schema error with a safe message containing no response content."""

        def consume(data):
            nonlocal most_recent_timestamp, finished
            if not isinstance(data, dict):
                raise CompletionEventError("Expected a completion object")
            if data.get("error") is not None:
                output.error_category = classify_error(json.dumps(data["error"]), 500)
                raise CompletionEventError(
                    "Server returned an error event; inspect server logs"
                )
            usage = data.get("usage")
            if usage is not None:
                if not isinstance(usage, dict):
                    raise CompletionEventError("Expected a usage object")
                # Keep only numeric token counts, never arbitrary server content.
                for key in ("prompt_tokens", "completion_tokens", "total_tokens"):
                    value = usage.get(key)
                    if value is not None:
                        if (
                            isinstance(value, bool)
                            or not isinstance(value, int)
                            or value < 0
                        ):
                            raise CompletionEventError("Invalid usage token count")
                        output.usage[key] = value
                output.output_len = output.usage.get(
                    "completion_tokens", output.output_len
                )
            choices = data.get("choices")
            if not isinstance(choices, list):
                raise CompletionEventError("Expected a choices list")
            if not choices:
                return
            choice = choices[0]
            if not isinstance(choice, dict):
                raise CompletionEventError("Expected a choice object")
            if "text" not in choice and choice.get("finish_reason") is None:
                raise CompletionEventError("Choice has neither text nor finish reason")
            text = choice.get("text", "")
            if not isinstance(text, str):
                raise CompletionEventError("Expected completion text to be a string")
            if text and finished:
                raise CompletionEventError("Received text after a finish event")
            if choice.get("finish_reason") is not None and not isinstance(
                choice["finish_reason"], str
            ):
                raise CompletionEventError("Expected a string finish reason")
            if text:
                timestamp = time.perf_counter()
                if not output.generated_text:
                    output.ttft = timestamp - st
                else:
                    output.itl.append(timestamp - most_recent_timestamp)
                most_recent_timestamp = timestamp
                output.generated_text += text
            if choice.get("finish_reason") is not None:
                finished = True

        try:
            async with session.post(
                url=api_url, json=payload, headers=headers
            ) as response:
                if response.status != 200:
                    # Do not persist response bodies, which may echo prompts or secrets.
                    category = classify_error(
                        await _response_error(response), response.status
                    )
                    _mark_failure(
                        output,
                        f"HTTP {response.status}; inspect server logs",
                        response.status,
                    )
                    output.error_category = category
                else:
                    if disable_stream:
                        consume(await response.json())
                        terminated = True
                    else:
                        async for raw in response.content:
                            line = raw.decode("utf-8").strip()
                            if (
                                not line
                                or line.startswith(":")
                                or line.startswith(("event:", "id:", "retry:"))
                            ):
                                continue
                            if not line.startswith("data:"):
                                raise ValueError("Expected an SSE data field")
                            chunk = line[5:].strip()
                            if chunk == "[DONE]":
                                terminated = True
                                break
                            consume(json.loads(chunk))
                    if not (terminated or finished):
                        output.error_category = "interrupted_stream"
                        output.error = "Stream ended without a finish event or [DONE]"
                    elif not output.generated_text:
                        output.error_category = "empty_response"
                        output.error = (
                            "Successful response contained no streamed token."
                        )
                    else:
                        output.success = True
                        if "completion_tokens" not in output.usage:
                            output.output_len = request_func_input.output_len
                            output.output_len_is_estimate = True
        except (ValueError, UnicodeError) as exc:
            output.error_category = output.error_category or "malformed_event"
            # Exception messages from JSON/decoding can contain response content.
            reason = (
                str(exc)
                if isinstance(exc, CompletionEventError)
                else "Invalid JSON or UTF-8 in completion event"
            )
            output.error = f"{reason}; inspect server logs"
        except Exception as exc:
            output.error_category = classify_error(type(exc).__name__)
            if output.error_category == "client_error":
                output.error_category = "interrupted_stream"
            output.error = (
                f"{type(exc).__name__}: request interrupted; inspect server logs"
            )
        finally:
            output.latency = time.perf_counter() - st

    if pbar:
        pbar.update(1)
    return output


async def async_request_truss(
    request_func_input: RequestFuncInput,
    pbar: Optional[tqdm] = None,
    disable_stream: bool = False,
    disable_ignore_eos: bool = False,
) -> RequestFuncOutput:
    api_url = request_func_input.api_url

    prompt = request_func_input.prompt

    async with _create_bench_client_session() as session:
        payload = {
            "model": request_func_input.model,
            "prompt": prompt,
            "temperature": 0.0,
            "best_of": 1,
            "max_tokens": request_func_input.output_len,
            "stream": not disable_stream,
            "ignore_eos": not disable_ignore_eos,
            **request_func_input.extra_request_body,
        }
        headers = get_auth_headers()

        output = RequestFuncOutput.init_new(request_func_input)

        generated_text = ""
        ttft = 0.0
        st = time.perf_counter()
        most_recent_timestamp = st
        try:
            async with session.post(
                url=api_url, json=payload, headers=headers
            ) as response:
                if response.status == 200:
                    async for chunk_bytes in response.content:
                        chunk_bytes = chunk_bytes.strip()
                        if not chunk_bytes:
                            continue

                        chunk = remove_prefix(chunk_bytes.decode("utf-8"), "data: ")
                        latency = time.perf_counter() - st
                        if chunk == "[DONE]":
                            pass
                        else:
                            data = json.loads(chunk)

                            # NOTE: Some completion API might have a last
                            # usage summary response without a token so we
                            # want to check a token was generated
                            if data["choices"][0]["text"]:
                                timestamp = time.perf_counter()
                                # First token
                                if ttft == 0.0:
                                    ttft = time.perf_counter() - st
                                    output.ttft = ttft

                                # Decoding phase
                                else:
                                    output.itl.append(timestamp - most_recent_timestamp)

                                most_recent_timestamp = timestamp
                                generated_text += data["choices"][0]["text"]

                    output.generated_text = generated_text
                    _mark_success_or_empty_failure(output)
                    output.latency = latency
                    output.output_len = request_func_input.output_len
                else:
                    _mark_failure(output, await _response_error(response), response.status)
        except Exception:
            exc_info = sys.exc_info()
            _mark_failure(output, "".join(traceback.format_exception(*exc_info)))

    if pbar:
        pbar.update(1)
    return output


async def async_request_sglang_generate(
    request_func_input: RequestFuncInput,
    pbar: Optional[tqdm] = None,
    disable_stream: bool = False,
    disable_ignore_eos: bool = False,
    return_logprob: bool = False,
) -> RequestFuncOutput:
    api_url = request_func_input.api_url
    prompt = request_func_input.prompt

    async with _create_bench_client_session() as session:
        payload = {
            ("text" if isinstance(prompt, str) else "input_ids"): prompt,
            "sampling_params": {
                "temperature": 0.0,
                "max_new_tokens": request_func_input.output_len,
                "ignore_eos": not disable_ignore_eos,
            },
            "stream": not disable_stream,
            "lora_path": request_func_input.lora_name,
            "return_logprob": return_logprob,
            "logprob_start_len": -1,
            **request_func_input.extra_request_body,
        }

        # Add image data if available
        if request_func_input.image_data:
            payload["image_data"] = request_func_input.image_data

        headers = get_auth_headers()

        output = RequestFuncOutput.init_new(request_func_input)

        generated_text = ""
        output_len = request_func_input.output_len
        ttft = 0.0
        st = time.perf_counter()
        most_recent_timestamp = st
        last_output_len = 0
        try:
            async with session.post(
                url=api_url, json=payload, headers=headers
            ) as response:
                if response.status == 200:
                    async for chunk_bytes in response.content:
                        chunk_bytes = chunk_bytes.strip()
                        if not chunk_bytes:
                            continue
                        # print(chunk_bytes)

                        chunk = remove_prefix(chunk_bytes.decode("utf-8"), "data: ")
                        latency = time.perf_counter() - st
                        if chunk == "[DONE]":
                            pass
                        else:
                            data = json.loads(chunk)

                            # NOTE: Some completion API might have a last
                            # usage summary response without a token so we
                            # want to check a token was generated
                            if data["text"]:
                                timestamp = time.perf_counter()
                                generated_text = data["text"]
                                output_len = data["meta_info"]["completion_tokens"]

                                # First token
                                if ttft == 0.0:
                                    ttft = time.perf_counter() - st
                                    output.ttft = ttft

                                # Decoding phase
                                else:
                                    num_new_tokens = output_len - last_output_len
                                    if num_new_tokens == 0:
                                        continue
                                    adjust_itl = (
                                        timestamp - most_recent_timestamp
                                    ) / num_new_tokens
                                    output.itl.extend([adjust_itl] * num_new_tokens)

                                most_recent_timestamp = timestamp
                                last_output_len = output_len

                    output.generated_text = generated_text
                    _mark_success_or_empty_failure(output)
                    output.latency = latency
                    output.output_len = output_len
                else:
                    _mark_failure(output, await _response_error(response), response.status)
        except Exception:
            exc_info = sys.exc_info()
            _mark_failure(output, "".join(traceback.format_exception(*exc_info)))
            print(f"{output.error=}")

    if pbar:
        pbar.update(1)
    return output


async def async_request_gserver(
    request_func_input: RequestFuncInput,
    pbar: Optional[tqdm] = None,
) -> RequestFuncOutput:
    raise NotImplementedError()


async def async_request_profile(api_url: str) -> RequestFuncOutput:
    async with _create_bench_client_session() as session:
        output = RequestFuncOutput()
        try:
            async with session.post(url=api_url) as response:
                if response.status == 200:
                    output.success = True
                else:
                    output.error = response.reason or ""
                    output.success = False
        except Exception:
            output.success = False
            exc_info = sys.exc_info()
            output.error = "".join(traceback.format_exception(*exc_info))

    return output


def get_model(pretrained_model_name_or_path: str) -> str:
    if os.getenv("SGLANG_USE_MODELSCOPE", "false").lower() == "true":
        import huggingface_hub.constants
        from modelscope import snapshot_download

        model_path = snapshot_download(
            model_id=pretrained_model_name_or_path,
            local_files_only=huggingface_hub.constants.HF_HUB_OFFLINE,
            ignore_file_pattern=[".*.pt", ".*.safetensors", ".*.bin"],
        )

        return model_path
    return pretrained_model_name_or_path


def get_tokenizer(
    pretrained_model_name_or_path: str,
) -> Union[PreTrainedTokenizer, PreTrainedTokenizerFast]:
    if AutoTokenizer is None:
        from transformers import AutoTokenizer as _AutoTokenizer
    else:
        _AutoTokenizer = AutoTokenizer
    assert (
        pretrained_model_name_or_path is not None
        and pretrained_model_name_or_path != ""
    )
    if pretrained_model_name_or_path.endswith(
        ".json"
    ) or pretrained_model_name_or_path.endswith(".model"):
        from sglang.srt.hf_transformers_utils import get_tokenizer

        return get_tokenizer(pretrained_model_name_or_path)

    if pretrained_model_name_or_path is not None and not os.path.exists(
        pretrained_model_name_or_path
    ):
        pretrained_model_name_or_path = get_model(pretrained_model_name_or_path)
    return _AutoTokenizer.from_pretrained(
        pretrained_model_name_or_path, trust_remote_code=True
    )


def get_dataset(
    args_dict: dict[str, t.Any], tokenizer: PreTrainedTokenizerBase
) -> list[dict]:
    if args_dict.get("hf_dataset") or args_dict.get("workload_path"):
        manifest, _ = prepare_workload_manifest(args_dict)
        return [DatasetRow(**row) for row in manifest["requests"]]
    tokenize_prompt = args_dict.get("tokenize_prompt", False)
    dataset_name = args_dict.get("dataset_name", "sharegpt")

    if dataset_name == "sharegpt":
        assert not tokenize_prompt
        input_requests = sample_sharegpt_requests(
            dataset_path=args_dict.get("dataset_path", ""),
            num_requests=args_dict.get("num_prompts", 1000),
            tokenizer=tokenizer,
            fixed_output_len=args_dict.get("sharegpt_output_len"),
            context_len=args_dict.get("sharegpt_context_len"),
            prompt_suffix=args_dict.get("prompt_suffix", ""),
            apply_chat_template=args_dict.get("apply_chat_template", False),
        )
    elif dataset_name.startswith("random"):
        input_requests = sample_random_requests(
            input_len=args_dict.get("random_input_len", 1024),
            output_len=args_dict.get("random_output_len", 1024),
            num_prompts=args_dict.get("num_prompts", 1000),
            range_ratio=args_dict.get("random_range_ratio", 0.0),
            tokenizer=tokenizer,
            dataset_path=args_dict.get("dataset_path", ""),
            random_sample=dataset_name == "random",
            return_text=not tokenize_prompt,
            apply_chat_template=args_dict.get("apply_chat_template", False),
        )
    elif dataset_name == "generated-shared-prefix":
        assert not tokenize_prompt
        input_requests = sample_generated_shared_prefix_requests(
            num_groups=args_dict.get("gsp_num_groups", 64),
            prompts_per_group=args_dict.get("gsp_prompts_per_group", 16),
            system_prompt_len=args_dict.get("gsp_system_prompt_len", 2048),
            question_len=args_dict.get("gsp_question_len", 128),
            output_len=args_dict.get("gsp_output_len", 256),
            system_prompt_partial_randomize=args_dict.get(
                "gsp_enable_system_prompt_partial_randomize", False
            ),
            system_prompt_partial_randomize_start_min=args_dict.get(
                "gsp_system_prompt_partial_randomize_start_min", 0.5
            ),
            system_prompt_partial_randomize_start_max=args_dict.get(
                "gsp_system_prompt_partial_randomize_start_max", 1.0
            ),
            tokenizer=tokenizer,
            args_dict=args_dict,
        )
    elif dataset_name == "mmmu":
        assert not tokenize_prompt
        input_requests = sample_mmmu_requests(
            num_requests=args_dict.get("num_prompts", 1000),
            tokenizer=tokenizer,
            fixed_output_len=args_dict.get("random_output_len", 1024),
            random_sample=True,
        )
    else:
        raise ValueError(f"Unknown dataset: {dataset_name}")
    return input_requests


def prepare_workload_manifest(args_dict: dict[str, t.Any]) -> tuple[dict[str, t.Any], dict[str, t.Any]]:
    """Load/tokenize the workload once so subsequent trials reuse exact requests."""
    if args_dict.get("hf_dataset") and args_dict.get("workload_path"):
        raise ValueError("Choose hf_dataset or an already frozen workload_path")
    if args_dict.get("hf_dataset"):
        from llm_optimizer.hf_workload import prepare_hf_workload
        manifest = prepare_hf_workload(
            {"repo_id": args_dict['hf_dataset'],
             "revision": args_dict.get('hf_dataset_revision'),
             "config": args_dict.get('hf_dataset_config'),
             "split": args_dict.get('hf_dataset_split', 'train')},
            args_dict.get('tokenizer') or args_dict['model'],
            args_dict.get('tokenizer_revision') or args_dict.get('model_revision'),
            args_dict.get('random_input_len', 1024), args_dict.get('random_output_len', 1024),
            args_dict.get('num_prompts', 1000), args_dict.get('seed', 1))
        return manifest, workload_metadata(manifest, args_dict, args_dict['model'], manifest['tokenizer'])
    if args_dict.get("workload_path"):
        from llm_optimizer.hf_workload import validate_manifest
        with open(args_dict["workload_path"], encoding="utf-8") as source:
            manifest = validate_manifest(json.load(source))
        return manifest, workload_metadata(manifest, args_dict, args_dict["model"], manifest["tokenizer"])
    tokenizer_id = args_dict.get("tokenizer") or args_dict["model"]
    tokenizer = get_tokenizer(tokenizer_id)
    input_requests = get_dataset(args_dict, tokenizer)
    manifest = build_workload_manifest(
        input_requests, args_dict, args_dict["model"], tokenizer_id
    )
    return manifest, workload_metadata(manifest, args_dict, args_dict["model"], tokenizer_id)


ASYNC_REQUEST_FUNCS = {
    "sglang": async_request_sglang_generate,
    "sglang-native": async_request_sglang_generate,
    "sglang-oai": async_request_openai_completions,
    "vllm": async_request_openai_completions,
    "lmdeploy": async_request_openai_completions,
    "trt": async_request_trt_llm,
    "gserver": async_request_gserver,
    "truss": async_request_truss,
}


@dataclass
class BenchmarkMetrics:
    total_requests: int
    completed: int
    failed: int
    failure_rate: float
    failure_categories: dict[str, int]
    benchmark_valid: bool
    total_input: int
    total_output: int
    total_output_retokenized: int
    request_throughput: float
    input_throughput: float
    output_throughput: float
    output_throughput_retokenized: float
    total_throughput: float
    total_throughput_retokenized: float
    mean_ttft_ms: float
    median_ttft_ms: float
    std_ttft_ms: float
    p95_ttft_ms: float
    p99_ttft_ms: float
    mean_tpot_ms: float
    median_tpot_ms: float
    std_tpot_ms: float
    p95_tpot_ms: float
    p99_tpot_ms: float
    mean_itl_ms: float
    median_itl_ms: float
    std_itl_ms: float
    p95_itl_ms: float
    p99_itl_ms: float
    max_itl_ms: float
    mean_e2e_latency_ms: float
    median_e2e_latency_ms: float
    std_e2e_latency_ms: float
    p95_e2e_latency_ms: float
    p99_e2e_latency_ms: float
    concurrency: float


SHAREGPT_URL = "https://huggingface.co/datasets/anon8231489123/ShareGPT_Vicuna_unfiltered/resolve/main/ShareGPT_V3_unfiltered_cleaned_split.json"


def build_workload_manifest(
    input_requests: list[DatasetRow], args_dict: dict[str, t.Any], model: str,
    tokenizer_id: str,
) -> dict[str, t.Any]:
    """Serialize the exact requests used by every trial and fingerprint them."""
    requests = [
        {
            "prompt": request.prompt,
            "prompt_len": request.prompt_len,
            "output_len": request.output_len,
        }
        for request in input_requests
    ]
    payload = {
        "requests": requests,
        "workload": {
            key: args_dict.get(key)
            for key in (
                "dataset_name", "dataset_path", "num_prompts", "request_rate",
                "max_concurrency", "seed", "random_input_len", "random_output_len",
                "random_range_ratio", "sharegpt_output_len", "sharegpt_context_len",
                "prompt_suffix", "apply_chat_template", "disable_ignore_eos",
                "extra_request_body",
                "framework", "model_revision", "tokenizer_revision",
            )
        },
        "model": model,
        "tokenizer": tokenizer_id,
    }
    canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return {
        **payload,
        "sha256": hashlib.sha256(canonical.encode("utf-8")).hexdigest(),
    }


def workload_metadata(
    manifest: dict[str, t.Any], args_dict: dict[str, t.Any], model: str,
    tokenizer_id: str,
) -> dict[str, t.Any]:
    """Return compact persisted identity/environment metadata for a run."""
    import importlib.metadata

    versions = {}
    for package in (
        "llm-optimizer", "numpy", "aiohttp", "transformers", "optuna",
        "vllm", "sglang", "tensorrt-llm",
    ):
        try:
            versions[package] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            pass
    return {
        "workload_sha256": manifest["sha256"],
        "dataset": {key: args_dict.get(key) for key in ("dataset_name", "dataset_path", "num_prompts")},
        "seed": args_dict.get("seed", 1),
        "model": model,
        "model_revision": args_dict.get("model_revision"),
        "tokenizer": tokenizer_id,
        "tokenizer_revision": manifest.get("tokenizer_revision", args_dict.get("tokenizer_revision")),
        "dataset_identity": manifest.get("dataset"),
        "row_indices": manifest.get("row_indices"),
        "framework": args_dict.get("framework"),
        "python_version": platform.python_version(),
        "platform": platform.platform(),
        "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"),
        "package_versions": versions,
    }


def download_and_cache_file(url: str, filename: Optional[str] = None):
    """Read and cache a file from a url."""
    if filename is None:
        filename = os.path.join("/tmp", url.split("/")[-1])

    # Check if the cache file already exists
    if is_file_valid_json(filename):
        return filename

    print(f"Downloading from {url} to {filename}")

    # Stream the response to show the progress bar
    response = requests.get(url, stream=True)
    response.raise_for_status()  # Check for request errors

    # Total size of the file in bytes
    total_size = int(response.headers.get("content-length", 0))
    chunk_size = 1024  # Download in chunks of 1KB

    # Use tqdm to display the progress bar
    with (
        open(filename, "wb") as f,
        tqdm(
            desc=filename,
            total=total_size,
            unit="B",
            unit_scale=True,
            unit_divisor=1024,
        ) as bar,
    ):
        for chunk in response.iter_content(chunk_size=chunk_size):
            f.write(chunk)
            bar.update(len(chunk))

    return filename


def is_file_valid_json(path):
    if not os.path.isfile(path):
        return False

    # TODO can fuse into the real file open later
    try:
        with open(path) as f:
            json.load(f)
        return True
    except JSONDecodeError as e:
        print(
            f"{path} exists but json loading fails ({e=}), thus treat as invalid file"
        )
        return False


@dataclass
class DatasetRow:
    prompt: str
    prompt_len: int
    output_len: int


def sample_mmmu_requests(
    num_requests: int,
    tokenizer: PreTrainedTokenizerBase,
    fixed_output_len: Optional[int] = None,
    random_sample: bool = True,
) -> list[DatasetRow]:
    """
    Sample requests from the MMMU dataset using HuggingFace datasets.

    Args:
        num_requests: Number of requests to sample.
        tokenizer: Tokenizer to use for token counting.
        fixed_output_len: If provided, use this fixed output length for all requests.
        random_sample: Whether to randomly sample or take the first N.

    Returns:
        List of tuples (prompt, prompt_token_len, output_token_len).
    """
    try:
        import base64
        import io

        from datasets import load_dataset
    except ImportError:
        raise ImportError("Please install datasets: pip install datasets")

    print("Loading MMMU dataset from HuggingFace...")

    try:
        print("Attempting to load MMMU Math dataset...")
        mmmu_dataset = load_dataset("MMMU/MMMU", "Math", split="test")
        print(
            f"Successfully loaded MMMU Math dataset from HuggingFace with {len(mmmu_dataset)} examples"
        )
    except Exception as e:
        print(f"Failed to load MMMU Math dataset: {e}")
        raise ValueError(f"Failed to load MMMU dataset: {e}")

    # Sample from the dataset
    if len(mmmu_dataset) > num_requests:
        if random_sample:
            # Random sample
            indices = random.sample(range(len(mmmu_dataset)), num_requests)
            sample_dataset = mmmu_dataset.select(indices)
        else:
            # Take first N
            sample_dataset = mmmu_dataset.select(
                range(min(num_requests, len(mmmu_dataset)))
            )
    else:
        print(f"Dataset has less than {num_requests} examples, using all examples")
        sample_dataset = mmmu_dataset

    print(f"Selected {len(sample_dataset)} examples for benchmarking")

    # Create prompts
    filtered_dataset = []

    for i, example in enumerate(sample_dataset):
        try:
            # Extract image_1
            image = example.get("image_1")

            if image is not None:
                if hasattr(image, "save"):
                    # Convert RGBA images to RGB before encoding
                    if image.mode == "RGBA":
                        image = image.convert("RGB")

                    # Encode image to base64
                    buffered = io.BytesIO()
                    image.save(buffered, format="JPEG")
                    img_str = base64.b64encode(buffered.getvalue()).decode("utf-8")
                    image_path = f"data:image/jpeg;base64,{img_str}"
                else:
                    continue

                # Extract the question
                question = example.get("question")

                # Create the prompt with image, question
                prompt = f"Question: {question}\n\nAnswer: "
                prompt = tokenizer.apply_chat_template(
                    [
                        {
                            "role": "user",
                            "content": [
                                {"type": "image_url", "image_url": {"url": image_path}},
                                {"type": "text", "text": prompt},
                            ],
                        }
                    ],
                    add_generation_prompt=True,
                    tokenize=False,
                )
                prompt = f"<image>{image_path}</image>{prompt}"

                # Calculate token lengths
                # Note: This is approximate since we're not rendering the actual image tokens
                prompt_token_ids = tokenizer.encode(prompt)
                prompt_len = (
                    len(prompt_token_ids) + 512
                )  # Add estimate for image tokens

                output_len = fixed_output_len if fixed_output_len is not None else 256

                filtered_dataset.append(
                    DatasetRow(
                        prompt=prompt, prompt_len=prompt_len, output_len=output_len
                    )
                )

        except Exception as e:
            print(f"Error processing example {i}: {e}")

    print(f"\nCreated {len(filtered_dataset)} MMMU prompts")
    return filtered_dataset


def sample_sharegpt_requests(
    dataset_path: str,
    num_requests: int,
    tokenizer: PreTrainedTokenizerBase,
    fixed_output_len: Optional[int] = None,
    context_len: Optional[int] = None,
    prompt_suffix: Optional[str] = "",
    apply_chat_template=False,
) -> list[DatasetRow]:
    if fixed_output_len is not None and fixed_output_len < 4:
        raise ValueError("output_len too small")

    # Download sharegpt if necessary
    if not is_file_valid_json(dataset_path) and dataset_path == "":
        dataset_path = download_and_cache_file(SHAREGPT_URL)

    # Load the dataset.
    with open(dataset_path) as f:
        dataset = json.load(f)

    # Filter out the conversations with less than 2 turns.
    dataset = [
        data
        for data in dataset
        if len(data.get("conversations", data.get("conversation", []))) >= 2
    ]
    # Only keep the first two turns of each conversation.
    dataset = [
        (
            data.get("conversations", data.get("conversation", []))[0]["value"],
            data.get("conversations", data.get("conversation", []))[1]["value"],
        )
        for data in dataset
    ]

    # Shuffle the dataset.
    random.shuffle(dataset)

    # Filter out sequences that are too long or too short
    filtered_dataset: list[DatasetRow] = []
    for i in range(len(dataset)):
        if len(filtered_dataset) == num_requests:
            break

        # Tokenize the prompts and completions.
        prompt = dataset[i][0]
        if prompt_suffix:
            prompt = (
                remove_suffix(prompt, ASSISTANT_SUFFIX)
                + prompt_suffix
                + ASSISTANT_SUFFIX
            )

        if apply_chat_template:
            prompt = tokenizer.apply_chat_template(
                [{"role": "user", "content": prompt}],
                add_generation_prompt=True,
                tokenize=False,
            )
            prompt = prompt.replace(tokenizer.bos_token, "")

        prompt_token_ids = tokenizer.encode(prompt)
        completion = dataset[i][1]
        completion_token_ids = tokenizer.encode(completion)
        prompt_len = len(prompt_token_ids)
        output_len = (
            len(completion_token_ids) if fixed_output_len is None else fixed_output_len
        )

        if prompt_len < 2 or output_len < 2:
            # Prune too short sequences.
            continue

        if context_len and prompt_len + output_len > context_len:
            # Prune too long sequences.
            continue

        filtered_dataset.append(
            DatasetRow(prompt=prompt, prompt_len=prompt_len, output_len=output_len)
        )

    print(f"#Input tokens: {np.sum([x.prompt_len for x in filtered_dataset])}")
    print(f"#Output tokens: {np.sum([x.output_len for x in filtered_dataset])}")
    return filtered_dataset


def _fixed_length_chat_prompt(tokenizer, content, target_len, return_text=True):
    """Fit user content without truncating the template or generation marker.

    Count the final text with encode's default special-token policy, matching
    text completion requests. Never silently report a nominal token count.
    """
    source = tokenizer.encode(content, add_special_tokens=False)
    if not source:
        raise ValueError("Chat prompt content must contain tokens")
    source = (source * ((target_len + len(source) - 1) // len(source)))[:target_len]
    def render(user_text):
        prompt = tokenizer.apply_chat_template(
            [{"role": "user", "content": user_text}],
            tokenize=False,
            add_generation_prompt=True,
        )
        return prompt, tokenizer.encode(prompt)

    def result(prompt, ids):
        return prompt if return_text else ids

    budget = target_len
    visited = set()
    best = None
    while 0 <= budget <= target_len and budget not in visited:
        visited.add(budget)
        user_text = tokenizer.decode(source[:budget], skip_special_tokens=False)
        prompt, ids = render(user_text)
        difference = target_len - len(ids)
        if difference == 0:
            return result(prompt, ids)
        if difference > 0 and (best is None or len(ids) > best[0]):
            best = (len(ids), user_text)
        budget += difference

    # Decode/encode is not an inverse: Unicode boundaries and merged tokens can
    # make the adjustment above oscillate across the target. Find an undershoot
    # before padding user content; never truncate the assistant generation marker.
    if best is None:
        for budget in range(target_len, -1, -1):
            if budget in visited:
                continue
            user_text = tokenizer.decode(source[:budget], skip_special_tokens=False)
            prompt, ids = render(user_text)
            if len(ids) == target_len:
                return result(prompt, ids)
            if len(ids) < target_len:
                best = (len(ids), user_text)
                break

    if best is not None:
        count, user_text = best
        while count < target_len:
            remaining = target_len - count
            options = []
            # Small deterministic padding stays inside the user message. Check
            # the entire formatted text each time rather than assuming a token
            # cost for a space, newline, or word on a particular tokenizer.
            for padding in (" x", " a", " 0", "\n", " ", ".", "x", "0"):
                candidate = user_text + padding
                prompt, ids = render(candidate)
                growth = len(ids) - count
                if growth == remaining:
                    return result(prompt, ids)
                if 0 < growth < remaining:
                    options.append((len(ids), candidate))
            if not options:
                break
            count, user_text = max(options, key=lambda option: option[0])

    raise ValueError(
        f"Cannot fit chat template into exactly {target_len} input tokens; "
        "the template may exceed the budget or this tokenizer cannot represent "
        "the remaining padding exactly."
    )


def sample_random_requests(
    input_len: int,
    output_len: int,
    num_prompts: int,
    range_ratio: float,
    tokenizer: PreTrainedTokenizerBase,
    dataset_path: str,
    random_sample: bool = True,
    return_text: bool = True,
    apply_chat_template: bool = False,
) -> list[DatasetRow]:
    input_lens = np.random.randint(
        max(int(input_len * range_ratio), 1),
        input_len + 1,
        size=num_prompts,
    )
    output_lens = np.random.randint(
        int(output_len * range_ratio),
        output_len + 1,
        size=num_prompts,
    )

    if random_sample:
        # Sample token ids from ShareGPT and repeat/truncate them to satisfy the input_lens

        # Download sharegpt if necessary
        if dataset_path and not is_file_valid_json(dataset_path):
            raise ValueError("Custom dataset_path is missing or invalid JSON")
        if not dataset_path:
            dataset_path = download_and_cache_file(SHAREGPT_URL)

        # Load the dataset.
        with open(dataset_path) as f:
            dataset = json.load(f)
        # Filter out the conversations with less than 2 turns.
        dataset = [
            data
            for data in dataset
            if len(data.get("conversations", data.get("conversation", []))) >= 2
        ]
        # Only keep the first two turns of each conversation.
        dataset = [
            (
                data.get("conversations", data.get("conversation", []))[0]["value"],
                data.get("conversations", data.get("conversation", []))[1]["value"],
            )
            for data in dataset
        ]
        # Shuffle the dataset.
        random.shuffle(dataset)

        # Filter out sequences that are too long or too short
        input_requests: list[DatasetRow] = []
        for data in dataset:
            i = len(input_requests)
            if i == num_prompts:
                break

            # Tokenize the prompts and completions.
            prompt = data[0]
            prompt_token_ids = tokenizer.encode(prompt)
            prompt_len = len(prompt_token_ids)

            # Skip empty prompt
            if prompt_len == 0:
                continue

            if prompt_len > input_lens[i]:
                input_ids = prompt_token_ids[: input_lens[i]]
            else:
                ratio = (input_lens[i] + prompt_len - 1) // prompt_len
                input_ids = (prompt_token_ids * ratio)[: input_lens[i]]
            input_content = input_ids
            if apply_chat_template:
                input_content = _fixed_length_chat_prompt(
                    tokenizer, prompt, int(input_lens[i]), return_text
                )
            elif return_text:
                input_content = tokenizer.decode(input_content)
            input_requests.append(
                DatasetRow(
                    prompt=input_content,
                    prompt_len=int(input_lens[i]),
                    output_len=int(output_lens[i]),
                )
            )
    else:
        # Sample token ids from random integers. This can cause some NaN issues.
        offsets = np.random.randint(0, tokenizer.vocab_size, size=num_prompts)
        input_requests = []
        for i in range(num_prompts):
            input_content = [
                (offsets[i] + i + j) % tokenizer.vocab_size
                for j in range(input_lens[i])
            ]
            if apply_chat_template:
                input_content = _fixed_length_chat_prompt(
                    tokenizer,
                    tokenizer.decode(input_content),
                    int(input_lens[i]),
                    return_text,
                )
            elif return_text:
                input_content = tokenizer.decode(input_content)
            input_requests.append(
                DatasetRow(
                    prompt=input_content,
                    prompt_len=int(input_lens[i]),
                    output_len=int(output_lens[i]),
                )
            )

    print(f"#Input tokens: {np.sum(input_lens)}")
    print(f"#Output tokens: {np.sum(output_lens)}")
    return input_requests


@lru_cache
def get_tokenizer_vocab(tokenizer):
    return list(tokenizer.get_vocab().values())


def gen_prompt(tokenizer, token_num):
    """Generate a random prompt of specified token length using tokenizer vocabulary."""
    all_available_tokens = get_tokenizer_vocab(tokenizer)
    selected_tokens = random.choices(all_available_tokens, k=token_num)
    return tokenizer.decode(selected_tokens)


def get_gen_prefix_cache_path(
    args_dict: dict[str, t.Any], tokenizer: PreTrainedTokenizerBase
) -> Path:
    """Create cache directory under ~/.cache/sglang/benchmark"""
    cache_dir = Path.home() / ".cache" / "sglang" / "benchmark"

    # Create a unique cache filename based on the generation parameters
    cache_key = (
        f"gen_shared_prefix_{args_dict.get('gsp_num_groups', 64)}_{args_dict.get('gsp_prompts_per_group', 16)}_"
        f"{args_dict.get('gsp_system_prompt_len', 2048)}_{args_dict.get('gsp_question_len', 128)}_{args_dict.get('gsp_output_len', 256)}_"
        f"{tokenizer.__class__.__name__}.pkl"
    )
    return cache_dir / cache_key


def sample_generated_shared_prefix_requests(
    num_groups: int,
    prompts_per_group: int,
    system_prompt_len: int,
    question_len: int,
    output_len: int,
    system_prompt_partial_randomize: bool,
    system_prompt_partial_randomize_start_min: float,
    system_prompt_partial_randomize_start_max: float,
    tokenizer: PreTrainedTokenizerBase,
    args_dict: dict[str, t.Any],
) -> list[DatasetRow]:
    """Generate benchmark requests with shared system prompts using random tokens and caching."""
    cache_path = get_gen_prefix_cache_path(args_dict, tokenizer)

    # Try to load from cache first
    if cache_path.exists() and not system_prompt_partial_randomize:
        print(f"\nLoading cached generated input data from {cache_path}")
        with open(cache_path, "rb") as f:
            return pickle.load(f)

    print("\nGenerating new input data...")

    # Generate system prompts for each group
    system_prompts = []
    for _ in range(num_groups):
        system_prompt = gen_prompt(tokenizer, system_prompt_len)
        system_prompts.append(system_prompt)

    # Generate questions
    questions = []
    for _ in range(num_groups * prompts_per_group):
        question = gen_prompt(tokenizer, question_len)
        questions.append(question)

    # Combine system prompts with questions
    input_requests = []
    total_input_tokens = 0
    total_output_tokens = 0

    for group_idx in tqdm(range(num_groups), desc="Generating system prompt"):
        system_prompt = system_prompts[group_idx]

        for prompt_idx in tqdm(
            range(prompts_per_group), desc="Generating questions", leave=False
        ):
            individual_system_prompt = system_prompt
            if system_prompt_partial_randomize:
                randomize_start_factor = random.uniform(
                    system_prompt_partial_randomize_start_min,
                    system_prompt_partial_randomize_start_max,
                )
                randomize_start = round(randomize_start_factor * system_prompt_len)
                randomize_len = system_prompt_len - randomize_start
                random_part = gen_prompt(tokenizer, randomize_len)
                system_prefix = tokenizer.decode(
                    tokenizer.encode(system_prompt)[:randomize_start]
                )
                system_prefix = system_prefix.replace(tokenizer.bos_token, "")
                individual_system_prompt = system_prefix + random_part

            question = questions[group_idx * prompts_per_group + prompt_idx]
            full_prompt = f"{individual_system_prompt}\n\n{question}"
            prompt_len = len(tokenizer.encode(full_prompt))

            input_requests.append(
                DatasetRow(
                    prompt=full_prompt, prompt_len=prompt_len, output_len=output_len
                )
            )
            total_input_tokens += prompt_len
            total_output_tokens += output_len

    # Shuffle questions
    random.shuffle(input_requests)

    # Print statistics
    print("\nGenerated shared prefix dataset statistics:")
    print(f"Number of groups: {num_groups}")
    print(f"Prompts per group: {prompts_per_group}")
    print(f"Total prompts: {len(input_requests)}")
    print(f"Total input tokens: {total_input_tokens}")
    print(f"Total output tokens: {total_output_tokens}")
    print(
        f"Average system prompt length: {sum(len(tokenizer.encode(sp)) for sp in system_prompts) / len(system_prompts):.1f} tokens"
    )
    print(
        f"Average question length: {sum(len(tokenizer.encode(q)) for q in questions) / len(questions):.1f} tokens\n"
    )

    # Save to cache
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    print(f"Caching generated input data to {cache_path}")
    with open(cache_path, "wb") as f:
        pickle.dump(input_requests, f)

    return input_requests


async def get_request(
    input_requests: list[DatasetRow],
    request_rate: float,
) -> AsyncGenerator[DatasetRow, None]:
    input_requests = iter(input_requests)
    for request in input_requests:
        yield request

        if request_rate == float("inf"):
            # If the request rate is infinity, then we don't need to wait.
            continue

        # Sample the request interval from the exponential distribution.
        interval = np.random.exponential(1.0 / request_rate)
        # The next request will be sent after the interval.
        await asyncio.sleep(interval)


def calculate_metrics(
    input_requests: list[DatasetRow],
    outputs: list[RequestFuncOutput],
    dur_s: float,
    tokenizer: PreTrainedTokenizerBase,
    backend: str,
) -> tuple[BenchmarkMetrics, list[int]]:
    output_lens: list[int] = []
    retokenized_output_lens: list[int] = []
    total_input = 0
    completed = 0
    failure_categories: dict[str, int] = {}
    itls: list[float] = []
    tpots: list[float] = []
    ttfts: list[float] = []
    e2e_latencies: list[float] = []
    for i in range(len(outputs)):
        if outputs[i].success:
            output_len = outputs[i].output_len
            retokenized_output_len = len(
                tokenizer.encode(outputs[i].generated_text, add_special_tokens=False)
            )
            if outputs[i].output_len_is_estimate:
                output_len = retokenized_output_len
            output_lens.append(output_len)
            retokenized_output_lens.append(retokenized_output_len)
            total_input += input_requests[i].prompt_len
            if output_len > 1:
                tpots.append((outputs[i].latency - outputs[i].ttft) / (output_len - 1))
            itls += outputs[i].itl
            ttfts.append(outputs[i].ttft)

            e2e_latencies.append(outputs[i].latency)

            completed += 1
        else:
            output_lens.append(0)
            retokenized_output_lens.append(0)
            category = outputs[i].error_category or classify_error(outputs[i].error)
            failure_categories[category] = failure_categories.get(category, 0) + 1

    if completed == 0:
        warnings.warn(
            "All requests failed. This is likely due to a misconfiguration "
            "on the benchmark arguments.",
            stacklevel=2,
        )
    total_requests = len(input_requests)
    missing = max(0, total_requests - len(outputs))
    if missing:
        failure_categories["missing_response"] = missing
    failed = total_requests - completed
    metrics = BenchmarkMetrics(
        total_requests=total_requests,
        completed=completed,
        failed=failed,
        failure_rate=failed / total_requests if total_requests else 1.0,
        failure_categories=failure_categories,
        benchmark_valid=(
            total_requests > 0
            and len(outputs) == total_requests
            and completed == total_requests
        ),
        total_input=total_input,
        total_output=sum(output_lens),
        total_output_retokenized=sum(retokenized_output_lens),
        request_throughput=completed / dur_s,
        input_throughput=total_input / dur_s,
        output_throughput=sum(output_lens) / dur_s,
        output_throughput_retokenized=sum(retokenized_output_lens) / dur_s,
        total_throughput=(total_input + sum(output_lens)) / dur_s,
        total_throughput_retokenized=(total_input + sum(retokenized_output_lens))
        / dur_s,
        mean_ttft_ms=np.mean(ttfts or 0)
        * 1000,  # ttfts is empty if streaming is not supported by backend
        median_ttft_ms=np.median(ttfts or 0) * 1000,
        std_ttft_ms=np.std(ttfts or 0) * 1000,
        p95_ttft_ms=np.percentile(ttfts or 0, 95) * 1000,
        p99_ttft_ms=np.percentile(ttfts or 0, 99) * 1000,
        mean_tpot_ms=np.mean(tpots or 0) * 1000,
        median_tpot_ms=np.median(tpots or 0) * 1000,
        std_tpot_ms=np.std(tpots or 0) * 1000,
        p95_tpot_ms=np.percentile(tpots or 0, 95) * 1000,
        p99_tpot_ms=np.percentile(tpots or 0, 99) * 1000,
        mean_itl_ms=np.mean(itls or 0) * 1000,
        median_itl_ms=np.median(itls or 0) * 1000,
        std_itl_ms=np.std(itls or 0) * 1000,
        p95_itl_ms=np.percentile(itls or 0, 95) * 1000,
        p99_itl_ms=np.percentile(itls or 0, 99) * 1000,
        max_itl_ms=np.max(itls or 0) * 1000,
        mean_e2e_latency_ms=np.mean(e2e_latencies or [np.nan]) * 1000,
        median_e2e_latency_ms=np.median(e2e_latencies or [np.nan]) * 1000,
        std_e2e_latency_ms=np.std(e2e_latencies or [np.nan]) * 1000,
        p95_e2e_latency_ms=np.percentile(e2e_latencies or [np.nan], 95) * 1000,
        p99_e2e_latency_ms=np.percentile(e2e_latencies or [np.nan], 99) * 1000,
        concurrency=np.sum(e2e_latencies) / dur_s,
    )

    return metrics, output_lens


async def benchmark(
    backend: str,
    api_url: str,
    base_url: str,
    model_id: str,
    tokenizer: PreTrainedTokenizerBase,
    input_requests: list[DatasetRow],
    request_rate: float,
    max_concurrency: Optional[int],
    disable_tqdm: bool,
    lora_names: list[str],
    extra_request_body: dict[str, Any],
    profile: bool,
    pd_separated: bool = False,
    flush_cache: bool = False,
    warmup_requests: int = 1,
    args_dict: dict[str, t.Any] = None,
):
    telemetry = (args_dict or {}).get("_telemetry")
    if backend in ASYNC_REQUEST_FUNCS:
        request_func = ASYNC_REQUEST_FUNCS[backend]
    else:
        raise ValueError(f"Unknown backend: {backend}")

    request_func_kwargs = {}
    if backend == "trt":
        request_func_kwargs["disable_ignore_eos"] = args_dict.get(
            "disable_ignore_eos", False
        )
    elif backend in ["sglang-oai", "vllm", "lmdeploy", "truss"]:
        request_func_kwargs["disable_stream"] = args_dict.get("disable_stream", False)
        request_func_kwargs["disable_ignore_eos"] = args_dict.get(
            "disable_ignore_eos", False
        )
    elif backend in ["sglang", "sglang-native"]:
        request_func_kwargs["disable_ignore_eos"] = args_dict.get(
            "disable_ignore_eos", False
        )
        request_func_kwargs["disable_stream"] = args_dict.get("disable_stream", False)
        request_func_kwargs["return_logprob"] = args_dict.get("return_logprob", False)

    # Limit concurrency
    # From https://github.com/vllm-project/vllm/pull/9390
    semaphore = asyncio.Semaphore(max_concurrency) if max_concurrency else None

    checkpoint_callback = (args_dict or {}).get("_checkpoint_callback")
    checkpoint_requests = set((args_dict or {}).get("_checkpoint_requests") or [])
    finished_requests = []
    finished_outputs = []
    finished_indices = []
    successful_requests = 0
    checkpoint_failure = asyncio.get_running_loop().create_future()

    async def limited_request_func(
        request_func_input, pbar, dataset_request, request_index
    ):
        nonlocal successful_requests
        if semaphore is None:
            output = await request_func(
                request_func_input=request_func_input, pbar=pbar, **request_func_kwargs
            )
        else:
            async with semaphore:
                output = await request_func(
                    request_func_input=request_func_input,
                    pbar=pbar,
                    **request_func_kwargs,
                )
        if checkpoint_callback is not None:
            # No await between recording a completion and making the decision:
            # the event loop cannot advance other requests past this checkpoint.
            finished_requests.append(dataset_request)
            finished_outputs.append(output)
            finished_indices.append(request_index)
            successful_requests += int(output.success)
            if successful_requests in checkpoint_requests or not output.success:
                elapsed = max(time.perf_counter() - benchmark_start_time, 1e-9)
                partial, _ = calculate_metrics(
                    finished_requests, finished_outputs, elapsed, tokenizer, backend
                )
                errors = request_errors(finished_outputs, finished_indices)
                if telemetry is not None:
                    telemetry.data["request_errors"] = errors
                    telemetry.data["request_accounting"] = {
                        key: getattr(partial, key)
                        for key in ("completed", "total_requests", "failed")
                    }
                    telemetry.save()
                try:
                    checkpoint_callback(
                        {**vars(partial), "benchmark_duration": elapsed}
                    )
                except Exception as exc:
                    if not checkpoint_failure.done():
                        checkpoint_failure.set_result(exc)
                    raise
        return output

    # Warmup
    if telemetry:
        telemetry.start("warmup")
    print(f"Starting warmup with {warmup_requests} sequences...")

    # Use the first request for all warmup iterations
    test_request = input_requests[0]
    test_prompt, test_prompt_len, test_output_len = (
        test_request.prompt,
        test_request.prompt_len,
        test_request.output_len,
    )
    if lora_names is not None and len(lora_names) != 0:
        lora_name = lora_names[0]
    else:
        lora_name = None

    if "<image>" in test_prompt:
        import re

        image_match = re.search(r"<image>(.*?)</image>(.*)", test_prompt, re.DOTALL)
        image_data = image_match.group(1) if image_match else None
        test_prompt = image_match.group(2) if image_match else test_prompt
    else:
        image_data = None

    # Create the test input once
    test_input = RequestFuncInput(
        model=model_id,
        prompt=test_prompt,
        api_url=api_url,
        prompt_len=test_prompt_len,
        output_len=min(test_output_len, 32),
        lora_name=lora_name,
        image_data=image_data,
        extra_request_body=extra_request_body,
    )

    # Run warmup requests
    warmup_tasks = []
    for _ in range(warmup_requests):
        warmup_tasks.append(
            asyncio.create_task(
                request_func(request_func_input=test_input, **request_func_kwargs)
            )
        )

    warmup_outputs = await asyncio.gather(*warmup_tasks)

    # Check if at least one warmup request succeeded
    if warmup_requests > 0 and not any(output.success for output in warmup_outputs):
        raise ValueError(
            "Warmup failed - Please make sure benchmark arguments "
            f"are correctly specified. Error: {warmup_outputs[0].error}"
        )
    else:
        print(
            f"Warmup completed with {warmup_requests} sequences. Starting main benchmark run..."
        )

    if telemetry:
        telemetry.stop("warmup")

    # Flush cache
    if ("sglang" in backend and _get_bool_env_var("SGLANG_IS_IN_CI")) or flush_cache:
        requests.post(base_url + "/flush_cache", headers=get_auth_headers())

    time.sleep(1.0)

    # Start profiler
    if profile:
        print("Starting profiler...")
        profile_output = await async_request_profile(
            api_url=base_url + "/start_profile"
        )
        if profile_output.success:
            print("Profiler started")

    pbar = None if disable_tqdm else tqdm(total=len(input_requests))

    # Run all requests
    benchmark_start_time = time.perf_counter()
    if telemetry:
        telemetry.start("benchmark")
    tasks: list[asyncio.Task] = []
    async def submit_requests():
        request_index = 0
        async for request in get_request(input_requests, request_rate):
            prompt, prompt_len, output_len = (
                request.prompt,
                request.prompt_len,
                request.output_len,
            )
            if lora_names is not None and len(lora_names) != 0:
                idx = random.randint(0, len(lora_names) - 1)
                lora_name = lora_names[idx]
            else:
                lora_name = None

            if "<image>" in prompt:
                import re

                image_match = re.search(r"<image>(.*?)</image>(.*)", prompt, re.DOTALL)
                image_data = image_match.group(1) if image_match else None
                prompt = image_match.group(2) if image_match else prompt
            else:
                image_data = None

            request_func_input = RequestFuncInput(
                model=model_id,
                prompt=prompt,
                api_url=api_url,
                prompt_len=prompt_len,
                output_len=output_len,
                lora_name=lora_name,
                image_data=image_data,
                extra_request_body=extra_request_body,
            )
            tasks.append(
                asyncio.create_task(
                    limited_request_func(
                        request_func_input=request_func_input,
                        pbar=pbar,
                        dataset_request=request,
                        request_index=request_index,
                    )
                )
            )
            request_index += 1
    producer = asyncio.create_task(submit_requests())
    measurement_completed = False
    try:
        # A pruning decision interrupts submission even with a finite request rate.
        await asyncio.wait(
            {producer, checkpoint_failure}, return_when=asyncio.FIRST_COMPLETED
        )
        if checkpoint_failure.done():
            raise checkpoint_failure.result()
        await producer
        outputs: list[RequestFuncOutput] = await asyncio.gather(*tasks)
        measurement_completed = True
    finally:
        # Includes queued requests waiting for the semaphore. Await cancellation
        # before the managed server is terminated by run_single_configuration.
        if not checkpoint_failure.done():
            checkpoint_failure.cancel()
        for task in [producer, *tasks]:
            if not task.done():
                task.cancel()
        await asyncio.gather(producer, *tasks, return_exceptions=True)
        if telemetry:
            telemetry.stop("benchmark", complete=measurement_completed)
        if pbar is not None:
            pbar.close()
        if profile:
            await async_request_profile(api_url=base_url + "/stop_profile")

    if "sglang" in backend:
        server_info = requests.get(base_url + "/get_server_info")
        if server_info.status_code == 200:
            server_info_json = server_info.json()
            if "decode" in server_info_json:
                server_info_json = server_info_json["decode"][0]
            accept_length = server_info_json["internal_states"][0].get(
                "avg_spec_accept_length", None
            )
        else:
            accept_length = None
    else:
        accept_length = None

    # Compute metrics and print results
    benchmark_duration = time.perf_counter() - benchmark_start_time
    if telemetry:
        # Retain the historical metric window (including post-request hooks).
        telemetry.data["metric_benchmark_duration_s"] = benchmark_duration
    metrics, output_lens = calculate_metrics(
        input_requests=input_requests,
        outputs=outputs,
        dur_s=benchmark_duration,
        tokenizer=tokenizer,
        backend=backend,
    )

    print("\n{s:{c}^{n}}".format(s=" Serving Benchmark Result ", n=50, c="="))
    print("{:<40} {:<10}".format("Backend:", backend))
    print("{:<40} {:<10}".format("Traffic request rate:", request_rate))
    print(
        "{:<40} {:<10}".format(
            "Max request concurrency:",
            max_concurrency if max_concurrency else "not set",
        )
    )
    print("{:<40} {:<10}".format("Successful requests:", metrics.completed))
    print("{:<40} {:<10.2f}".format("Benchmark duration (s):", benchmark_duration))
    print("{:<40} {:<10}".format("Total input tokens:", metrics.total_input))
    print("{:<40} {:<10}".format("Total generated tokens:", metrics.total_output))
    print(
        "{:<40} {:<10}".format(
            "Total generated tokens (retokenized):", metrics.total_output_retokenized
        )
    )
    print(
        "{:<40} {:<10.2f}".format(
            "Request throughput (req/s):", metrics.request_throughput
        )
    )
    print(
        "{:<40} {:<10.2f}".format(
            "Input token throughput (tok/s):", metrics.input_throughput
        )
    )
    print(
        "{:<40} {:<10.2f}".format(
            "Output token throughput (tok/s):", metrics.output_throughput
        )
    )
    print(
        "{:<40} {:<10.2f}".format(
            "Total token throughput (tok/s):", metrics.total_throughput
        )
    )
    print("{:<40} {:<10.2f}".format("Concurrency:", metrics.concurrency))
    if accept_length:
        print("{:<40} {:<10.2f}".format("Accept length:", accept_length))
    print("{s:{c}^{n}}".format(s="End-to-End Latency", n=50, c="-"))
    print(
        "{:<40} {:<10.2f}".format("Mean E2E Latency (ms):", metrics.mean_e2e_latency_ms)
    )
    print(
        "{:<40} {:<10.2f}".format(
            "Median E2E Latency (ms):", metrics.median_e2e_latency_ms
        )
    )
    print("{s:{c}^{n}}".format(s="Time to First Token", n=50, c="-"))
    print("{:<40} {:<10.2f}".format("Mean TTFT (ms):", metrics.mean_ttft_ms))
    print("{:<40} {:<10.2f}".format("Median TTFT (ms):", metrics.median_ttft_ms))
    print("{:<40} {:<10.2f}".format("P95 TTFT (ms):", metrics.p95_ttft_ms))
    print("{:<40} {:<10.2f}".format("P99 TTFT (ms):", metrics.p99_ttft_ms))
    print("{s:{c}^{n}}".format(s="Inter-Token Latency", n=50, c="-"))
    print("{:<40} {:<10.2f}".format("Mean ITL (ms):", metrics.mean_itl_ms))
    print("{:<40} {:<10.2f}".format("Median ITL (ms):", metrics.median_itl_ms))
    print("{:<40} {:<10.2f}".format("P95 ITL (ms):", metrics.p95_itl_ms))
    print("{:<40} {:<10.2f}".format("P99 ITL (ms):", metrics.p99_itl_ms))
    print("{:<40} {:<10.2f}".format("Max ITL (ms):", metrics.max_itl_ms))
    print("=" * 50)

    if (
        metrics.median_ttft_ms is not None
        and metrics.mean_itl_ms is not None
        and metrics.output_throughput is not None
    ):
        result = {
            # Arguments
            "backend": args_dict.get("backend"),
            "dataset_name": args_dict.get("dataset_name"),
            "request_rate": request_rate,
            "max_concurrency": max_concurrency,
            "sharegpt_output_len": args_dict.get("sharegpt_output_len"),
            "random_input_len": args_dict.get("random_input_len"),
            "random_output_len": args_dict.get("random_output_len"),
            "random_range_ratio": args_dict.get("random_range_ratio"),
            # Results
            "duration": benchmark_duration,
            "total_requests": metrics.total_requests,
            "completed": metrics.completed,
            "failed": metrics.failed,
            "failure_rate": metrics.failure_rate,
            "failure_categories": metrics.failure_categories,
            "benchmark_valid": metrics.benchmark_valid,
            "total_input_tokens": metrics.total_input,
            "total_output_tokens": metrics.total_output,
            "total_output_tokens_retokenized": metrics.total_output_retokenized,
            "request_throughput": metrics.request_throughput,
            "input_throughput": metrics.input_throughput,
            "output_throughput": metrics.output_throughput,
            "total_throughput": metrics.total_throughput,
            "mean_e2e_latency_ms": metrics.mean_e2e_latency_ms,
            "median_e2e_latency_ms": metrics.median_e2e_latency_ms,
            "std_e2e_latency_ms": metrics.std_e2e_latency_ms,
            "p95_e2e_latency_ms": metrics.p95_e2e_latency_ms,
            "p99_e2e_latency_ms": metrics.p99_e2e_latency_ms,
            "mean_ttft_ms": metrics.mean_ttft_ms,
            "median_ttft_ms": metrics.median_ttft_ms,
            "std_ttft_ms": metrics.std_ttft_ms,
            "p95_ttft_ms": metrics.p95_ttft_ms,
            "p99_ttft_ms": metrics.p99_ttft_ms,
            "mean_tpot_ms": metrics.mean_tpot_ms,
            "median_tpot_ms": metrics.median_tpot_ms,
            "std_tpot_ms": metrics.std_tpot_ms,
            "p95_tpot_ms": metrics.p95_tpot_ms,
            "p99_tpot_ms": metrics.p99_tpot_ms,
            "mean_itl_ms": metrics.mean_itl_ms,
            "median_itl_ms": metrics.median_itl_ms,
            "std_itl_ms": metrics.std_itl_ms,
            "p95_itl_ms": metrics.p95_itl_ms,
            "p99_itl_ms": metrics.p99_itl_ms,
            "concurrency": metrics.concurrency,
            "accept_length": accept_length,
        }
    else:
        print(f"Error running benchmark for request rate: {request_rate}")
        print("-" * 30)

    # Failed trials are excluded from metric rows, so preserve bounded request
    # diagnostics separately. Never include prompts or generated text here.
    result["request_errors"] = request_errors(outputs)
    telemetry = args_dict.get("_telemetry")
    if telemetry is not None:
        telemetry.data["request_errors"] = result["request_errors"]
        telemetry.save()

    result_details = {
        "input_lens": [output.prompt_len for output in outputs],
        "output_lens": output_lens,
        "ttfts": [output.ttft for output in outputs],
        "itls": [output.itl for output in outputs],
        "generated_texts": [output.generated_text for output in outputs],
        "errors": [output.error for output in outputs],
        "error_categories": [output.error_category for output in outputs],
        "usages": [output.usage for output in outputs],
    }

    if args_dict.get("output_details"):
        return result | result_details
    return result


def check_chat_template(model_path):
    try:
        tokenizer = AutoTokenizer.from_pretrained(model_path, trust_remote_code=True)
        return "chat_template" in tokenizer.init_kwargs
    except Exception as e:
        print(f"Fail to load tokenizer config with error={e}")
        return False


def run_benchmark(args_dict: dict[str, t.Any]):
    telemetry = args_dict.get("_telemetry")
    if telemetry:
        telemetry.start("client_preparation")
    # Set default value for max_concurrency if not present
    max_concurrency = args_dict.get("max_concurrency")

    # Set default value for warmup_requests if not present
    warmup_requests = args_dict.get("warmup_requests", 1)
    args_dict.get("output_details", False)
    tokenize_prompt = args_dict.get("tokenize_prompt", False)

    safe_args = {k: v for k, v in args_dict.items() if not k.startswith("_")}
    print(f"benchmark_args={safe_args}")

    # Set global environments
    set_ulimit()
    random.seed(args_dict.get("seed", 1))
    np.random.seed(args_dict.get("seed", 1))

    extra_request_body = {}
    if "extra_request_body" in args_dict and args_dict["extra_request_body"]:
        extra_request_body = json.loads(args_dict["extra_request_body"])

    if tokenize_prompt:
        assert args_dict.get("backend") == "sglang", (
            "`--tokenize-prompt` only compatible with `--backend sglang` currently"
        )

    # Set url
    port = args_dict.get("port")
    if port is None:
        port = {
            "sglang": 30000,
            "sglang-native": 30000,
            "sglang-oai": 30000,
            "lmdeploy": 23333,
            "vllm": 8000,
            "trt": 8000,
            "gserver": 9988,
            "truss": 8080,
        }.get(args_dict.get("backend"), 30000)

    host = args_dict.get("host", "127.0.0.1")
    base_url = args_dict.get("base_url")

    model_url = (
        f"{base_url}/v1/models" if base_url else f"http://{host}:{port}/v1/models"
    )

    backend = args_dict.get("backend")
    if backend in ["sglang", "sglang-native"]:
        api_url = (
            f"{base_url}/generate" if base_url else f"http://{host}:{port}/generate"
        )
    elif backend in ["sglang-oai", "vllm", "lmdeploy"]:
        api_url = (
            f"{base_url}/v1/completions"
            if base_url
            else f"http://{host}:{port}/v1/completions"
        )
    elif backend == "trt":
        api_url = (
            f"{base_url}/v2/models/ensemble/generate_stream"
            if base_url
            else f"http://{host}:{port}/v2/models/ensemble/generate_stream"
        )
        if "model" not in args_dict or args_dict["model"] is None:
            print("Please provide a model using `--model` when using `trt` backend.")
            sys.exit(1)
    elif backend == "gserver":
        api_url = base_url if base_url else f"{host}:{port}"
        if "model" not in args_dict or args_dict["model"] is None:
            args_dict["model"] = "default"
    elif backend == "truss":
        api_url = (
            f"{base_url}/v1/models/model:predict"
            if base_url
            else f"http://{host}:{port}/v1/models/model:predict"
        )

    if base_url is None:
        base_url = f"http://{host}:{port}"

    # Get model name
    model = args_dict.get("model")
    if model is None:
        if backend == "truss":
            print(
                "Please provide a model with `--model` when using truss backend. e.g. --model meta-llama/Llama-3.1-8B-Instruct"
            )
            sys.exit(1)
        try:
            response = requests.get(model_url, headers=get_auth_headers())
            model_list = response.json().get("data", [])
            model = model_list[0]["id"] if model_list else None
        except Exception as e:
            print(f"Failed to fetch model from {model_url}. Error: {e}")
            print(
                "Please specify the correct host and port using `--host` and `--port`."
            )
            sys.exit(1)

    if model is None:
        print("No model specified or found. Please provide a model using `--model`.")
        sys.exit(1)
    args_dict["model"] = model

    if not check_chat_template(model):
        print(
            "\nWARNING It is recommended to use the `Chat` or `Instruct` model for benchmarking.\n"
            "Because when the tokenizer counts the output tokens, if there is gibberish, it might count incorrectly.\n"
        )

    pass  # Suppress full manifest output

    # Read dataset
    model_id = model
    tokenizer_id = args_dict.get("tokenizer", model_id)
    tokenizer = get_tokenizer(tokenizer_id)
    manifest = args_dict.get("_request_manifest")
    if manifest is not None:
        input_requests = [DatasetRow(**item) for item in manifest["requests"]]
    else:
        input_requests = get_dataset(args_dict, tokenizer)

    flush_cache = args_dict.get("flush_cache", False)

    if telemetry:
        telemetry.stop("client_preparation")

    return asyncio.run(
        benchmark(
            backend=backend,
            api_url=api_url,
            base_url=base_url,
            model_id=model_id,
            tokenizer=tokenizer,
            input_requests=input_requests,
            request_rate=args_dict.get("request_rate", float("inf")),
            max_concurrency=max_concurrency,
            disable_tqdm=args_dict.get("disable_tqdm", False),
            lora_names=args_dict.get("lora_name"),
            extra_request_body=extra_request_body,
            profile=args_dict.get("profile", False),
            pd_separated=args_dict.get("pd_separated", False),
            flush_cache=flush_cache,
            warmup_requests=warmup_requests,
            args_dict=args_dict,
        )
    )


def set_ulimit(target_soft_limit=65535):
    resource_type = resource.RLIMIT_NOFILE
    current_soft, current_hard = resource.getrlimit(resource_type)

    if current_soft < target_soft_limit:
        try:
            resource.setrlimit(resource_type, (target_soft_limit, current_hard))
        except ValueError as e:
            print(f"Fail to set RLIMIT_NOFILE: {e}")


class LoRAPathAction(argparse.Action):
    def __call__(self, parser, namespace, values, option_string=None):
        setattr(namespace, self.dest, [])
        for lora_name in values:
            getattr(namespace, self.dest).append(lora_name)


def add_parser_args(parser: ArgumentParser):
    """Add arguments to a parser."""
    parser.add_argument(
        "--backend",
        type=str,
        choices=list(ASYNC_REQUEST_FUNCS.keys()),
        default="sglang",
        help="Must specify a backend, depending on the LLM Inference Engine.",
    )
    parser.add_argument(
        "--base-url",
        type=str,
        default=None,
        help="Server or API base url if not using http host and port.",
    )
    parser.add_argument(
        "--dataset-name",
        type=str,
        default="sharegpt",
        choices=["sharegpt", "random", "random-ids", "generated-shared-prefix", "mmmu"],
        help="Name of the dataset to benchmark on.",
    )
    parser.add_argument(
        "--dataset-path", type=str, default="", help="Path to the dataset."
    )
    parser.add_argument(
        "--tokenizer",
        type=str,
        help="Name or path of the tokenizer. If not set, using the model conf.",
    )
    parser.add_argument(
        "--num-prompts",
        type=int,
        default=1000,
        help="Number of prompts to process. Default is 1000.",
    )
    parser.add_argument(
        "--sharegpt-output-len",
        type=int,
        default=None,
        help="Output length for each request. Overrides the output length from the ShareGPT dataset.",
    )
    parser.add_argument(
        "--sharegpt-context-len",
        type=int,
        default=None,
        help="The context length of the model for the ShareGPT dataset. Requests longer than the context length will be dropped.",
    )
    parser.add_argument(
        "--random-input-len",
        type=int,
        default=1024,
        help="Number of input tokens per request, used only for random dataset.",
    )
    parser.add_argument(
        "--random-output-len",
        default=1024,
        type=int,
        help="Number of output tokens per request, used only for random dataset.",
    )
    parser.add_argument(
        "--random-range-ratio",
        type=float,
        default=0.0,
        help="Range of sampled ratio of input/output length, "
        "used only for random dataset.",
    )
    parser.add_argument(
        "--request-rate",
        type=float,
        default=float("inf"),
        help="Number of requests per second. If this is inf, then all the requests are sent at time 0. "
        "Otherwise, we use Poisson process to synthesize the request arrival times. Default is inf.",
    )
    parser.add_argument(
        "--max-concurrency",
        type=int,
        default=None,
        help="Maximum number of concurrent requests. This can be used "
        "to help simulate an environment where a higher level component "
        "is enforcing a maximum number of concurrent requests. While the "
        "--request-rate argument controls the rate at which requests are "
        "initiated, this argument will control how many are actually allowed "
        "to execute at a time. This means that when used in combination, the "
        "actual request rate may be lower than specified with --request-rate, "
        "if the server is not processing requests fast enough to keep up.",
    )
    parser.add_argument("--output-file", type=str, help="Output JSONL file name.")
    parser.add_argument(
        "--output-details", action="store_true", help="Output details of benchmarking."
    )
    parser.add_argument(
        "--disable-tqdm",
        action="store_true",
        help="Specify to disable tqdm progress bar.",
    )
    parser.add_argument(
        "--disable-stream",
        action="store_true",
        help="Disable streaming mode.",
    )
    parser.add_argument(
        "--return-logprob",
        action="store_true",
        help="Return logprob.",
    )
    parser.add_argument("--seed", type=int, default=1, help="The random seed.")
    parser.add_argument(
        "--disable-ignore-eos",
        action="store_true",
        help="Disable ignoring EOS.",
    )
    parser.add_argument(
        "--extra-request-body",
        metavar='{"key1": "value1", "key2": "value2"}',
        type=str,
        help="Append given JSON object to the request payload. You can use this to specify"
        "additional generate params like sampling params.",
    )
    parser.add_argument(
        "--apply-chat-template",
        action="store_true",
        help="Apply chat template",
    )
    parser.add_argument(
        "--profile",
        action="store_true",
        help="Use Torch Profiler. The endpoint must be launched with "
        "SGLANG_TORCH_PROFILER_DIR to enable profiler.",
    )
    parser.add_argument(
        "--lora-name",
        type=str,
        nargs="*",
        default=None,
        action=LoRAPathAction,
        help="The names of LoRA adapters. You can provide a list of names in the format {name} {name} {name}...",
    )
    parser.add_argument(
        "--prompt-suffix",
        type=str,
        default="",
        help="Suffix applied to the end of all user prompts, followed by assistant prompt suffix.",
    )
    parser.add_argument(
        "--pd-separated",
        action="store_true",
        help="Benchmark PD disaggregation server",
    )
    parser.add_argument(
        "--flush-cache",
        action="store_true",
        help="Flush the cache before running the benchmark",
    )
    parser.add_argument(
        "--warmup-requests",
        type=int,
        default=1,
        help="Number of warmup requests to run before the benchmark",
    )
    parser.add_argument(
        "--tokenize-prompt",
        action="store_true",
        help="Use integer ids instead of string for inputs. Useful to control prompt lengths accurately",
    )

    group = parser.add_argument_group("generated-shared-prefix dataset arguments")
    group.add_argument(
        "--gsp-num-groups",
        type=int,
        default=64,
        help="Number of system prompt groups for generated-shared-prefix dataset",
    )
    group.add_argument(
        "--gsp-prompts-per-group",
        type=int,
        default=16,
        help="Number of prompts per system prompt group for generated-shared-prefix dataset",
    )
    group.add_argument(
        "--gsp-system-prompt-len",
        type=int,
        default=2048,
        help="Target length in tokens for system prompts in generated-shared-prefix dataset",
    )
    group.add_argument(
        "--gsp-question-len",
        type=int,
        default=128,
        help="Target length in tokens for questions in generated-shared-prefix dataset",
    )
    group.add_argument(
        "--gsp-output-len",
        type=int,
        default=256,
        help="Target length in tokens for outputs in generated-shared-prefix dataset",
    )
    group.add_argument(
        "--gsp-enable-system-prompt-partial-randomize",
        action="store_true",
        help="Enable partially randomized system prompt in generated-shared-prefix dataset",
    )
    group.add_argument(
        "--gsp-system-prompt-partial-randomize-start-min",
        type=float,
        default=0.5,
        help="Specify the minimal starting point for system prompt randomization in generated-shared-prefix dataset",
    )
    group.add_argument(
        "--gsp-system-prompt-partial-randomize-start-max",
        type=float,
        default=1.0,
        help="Specify the max starting point for system prompt randomization in generated-shared-prefix dataset",
    )
